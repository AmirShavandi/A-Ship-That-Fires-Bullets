import pygame
from pygame.sprite import Sprite

class Boss(Sprite):
    def __init__(self, ai_game):
        super().__init__()
        self.settings = ai_game.settings
        self.screen = ai_game.screen
        self.screen_rect = ai_game.screen.get_rect()

        # Load the boss image and set its rect attribute
        self.image = pygame.image.load('alian.bmp')  # Ensure the image is in the correct path
        self.rect = self.image.get_rect()

        # Start each new boss at the top center of the screen
        self.rect.centerx = self.screen_rect.centerx
        self.rect.top = self.screen_rect.top

        # Store a decimal value for the boss's position
        self.y = float(self.rect.y)

        # Set movement speed
        self.speed = 1

    def update(self):
        """Move the boss vertically across the screen."""
        self.y += self.speed
        if self.y > self.screen_rect.height * 0.1:  # Move down slightly to be visible
            self.y = self.screen_rect.height * 0.1
            self.speed = -self.speed  # Reverse direction
        elif self.y < 0:
            self.y = 0
            self.speed = -self.speed  # Reverse direction

        self.rect.y = self.y

    def draw_boss(self):
        """Draw the boss at its current location."""
        self.screen.blit(self.image, self.rect)
