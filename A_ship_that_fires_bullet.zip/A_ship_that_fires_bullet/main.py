import sys # we import the system moudule into our project
from time import sleep # we import sleep
import pygame # we import pygame
from setting import Settings# we import settings
from game_stats import GameStats # we import game stats
from ship import Ship # we import ship
from bullet import Bullet # we import bullet
from alien import Alien # we import alien
from button import Button # we import button
from scoreboard import Scoreboard # we import scoreboard
from boss_aliesn import Boss  # we import boss alien


class AlienInvasion: # we create the alien invasion class
    def __init__(self): # we create a init method
        pygame.init() # we make pygame method
        self.clock = pygame.time.Clock() # we import pygame clock
        self.settings = Settings() # we import settings
        self.screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN) # we make the screen fullscreen so it covers the screen
        self.settings.screen_width = self.screen.get_rect().width # we get the screen width and the screen height
        self.settings.screen_height = self.screen.get_rect().height
        pygame.display.set_caption("Alien Invasion") # we set the caption to alien invasion where the title is
        self.stats = GameStats(self) # we import game stats
        self.sb = Scoreboard(self) # we import scoreboard

        self.ship = Ship(self) # we import ship
        self.bullets = pygame.sprite.Group() # we import bullet as a sprite in python
        self.aliens = pygame.sprite.Group() # we import aliens as a sprite in python
        self._create_fleet() # we creat a fleet
        self.bg_color = (230, 230, 230) # we set the back ground color
        self.game_active = False # we make the game active

        self.play_button = Button(self, "Play") # we make a button to appear on the screen play

    def _create_fleet(self): # we creat a new fleet def that defins the new fleet of aliens
        alien = Alien(self) # we import aliens for it so it can make the fleet
        alien_width, alien_height = alien.rect.size # this checks the aliens hight and how many they can fit in it
        current_x = alien_width # we create currenct x and cirrent y witch sets the alien widtha dn alien height
        current_y = alien_height #
        rows = 0  # Initialize a row counter

        while rows < 5:  # Limit to 5 rows
            while current_x < (self.settings.screen_width - 2 * alien_width): # so at the end there is 2 aliens spot
                self._create_alien(current_x, current_y) # this give the height and width of the alien
                current_x += 2 * alien_width # we give the alien width
            current_x = alien_width
            current_y += alien_height
            rows += 1  # Increment the row counter

    def _create_alien(self, x_position, y_position): # we create this becuse thats what lets us import alien in our project
        new_alien = Alien(self) # we create a new alien
        new_alien.x = x_position # we create x alien for the position
        new_alien.rect.x = x_position # this gets the rect of the x position
        new_alien.rect.y = y_position # this gets the rect of the x positionn
        self.aliens.add(new_alien)# we create add aliens so we add the aliens into our project

    def _update_aliens(self): # we make this to update the aliens
        self._check_fleet_edges() # we check the fleets edges
        self.aliens.update() # we update aliens

        if pygame.sprite.spritecollideany(self.ship, self.aliens): # we check for collide points
            self._ship_hit() # we make ship hit

        self._check_aliens_bottom() # we check alien bottom

    def center_ship(self): # we center ship
        self.ship.center_ship() # this code sends it so it can center the ship

    def _check_aliens_bottom(self): # check if the aliens have toched the ground
        for alien in self.aliens.sprites(): # this makes the alien a sprite so it can collide
            if alien.rect.bottom >= self.settings.screen_height: # if the aleins toches the  bottom of the scrren in breaks this code
                break # this brkes the code

    def run_game(self): # this code runs the game or checks for the coreect codes so the game can run
        while True: # this cdode says if this is true it rins the game
            self._check_events() # this checks the vents of keyprees
            if self.game_active: # if game is active or if the game is running
                self.ship.update() # we update the ship
                self._update_bullets() # we update the bullets
                self._update_aliens()# we update the aliens
            self._update_screen() # e update the screen
            self.clock.tick(60) # we make the clock tick for 60 mill or 1 sic and it update

    def _update_bullets(self): # this code checks the update bullet code
        self.bullets.update() # this updates the bullets so they can go slowly


        for bullet in self.bullets.copy(): # we copy the bullets
            if bullet.rect.bottom <= 0: # we tell it if bullets hits the top
                self.bullets.remove(bullet ) # it removes the bullets

        self._check_bullet_alien_collisions() # this checks to see if any bullets have hit the aliens

    def _check_bullet_alien_collisions(self): # this checks the bullets collision with the alien
        collisions = pygame.sprite.groupcollide(self.bullets, self.aliens, True, True) # this checks any collisions with the the bullets and the aliens
        if collisions: # it says if there is any collisions with the aliens and the bullet
            for aliens in collisions.values(): # this checks the values so it knows what the score is gonna be
                self.stats.score += self.settings.alien_points * len(aliens) # this add teh len of the score
            self.sb.prep_score() # this preps the score so it loads on the screen
            self.sb.check_high_score() # this checks the high scores

        if not self.aliens: # this says if there is no aliens
            self.bullets.empty() # it delets al the bullets
            self._create_fleet() # and then creats a new fleet for you to fight

            self.stats.level += 1# each time you earn one stat point

            self.sb.prep_level()# this preeps the level

            # Create boss alien at level 5
            if self.stats.level == 5: # once you have reached level 5
                self._create_boss() # it creats a new boss

    def _create_boss(self):# this creats a new boss
        boss_alien = Boss(self) # this is from the boss alien class
        boss_alien.rect.centerx = self.settings.screen_width // 2 # this centers the x on our screen
        boss_alien.rect.top = 0  # You can adjust this if needed
        self.aliens.add(boss_alien) # this adds a boss alien

    def _ship_hit(self): # this makes the ship hit
        if self.stats.ships_left > 0: # if the the hsip left is bigger then 0
            self.stats.ships_left -= 1 # delet one live
            self.bullets.empty() # then delets all bullest on screen
            self.aliens.empty() # empty all aliens
            self._create_fleet() # create a new fleet
            self.sb.prep_ships() # prep the sship center
            self.ship.center_ship()
            sleep(0.5) # then wait o.5 sic
        else:
            self.game_active = False# if game is stoped show the players mouse
            pygame.mouse.set_visible(True)

    def _check_fleet_edges(self): # this will check the screen or the edge to see if the fleet has hit and once that happens it changes directions
        for alien in self.aliens.sprites():
            if isinstance(alien, Alien) and alien.check_edges():  # Check only regular aliens
                self._change_fleet_direction() # this changes the fleet direction after each hit

                break

    def _change_fleet_direction(self): # this makes the fleet change
        for alien in self.aliens.sprites():
            alien.rect.y += self.settings.fleet_drop_speed
        self.settings.fleet_direction *= -1

    def _check_events(self): # this checks the event on the mouse to see if we have clicked
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = pygame.mouse.get_pos()
                self._check_play_button(mouse_pos)
            elif event.type == pygame.KEYDOWN:
                self._check_keydown_events(event)
            elif event.type == pygame.KEYUP:
                self._check_keyup_events(event)

    def _check_play_button(self, mouse_pos):# all this code is for it to create a new button that appears when we start the game
        button_clicked = self.play_button.rect.collidepoint(mouse_pos)
        if button_clicked and not self.game_active:
            self.settings.initialize_dynamic_settings()
            self.stats.reset_stats()
            self.sb.prep_score()
            self.sb.prep_level()
            self.sb.prep_ships()

            self.game_active = True
            self.bullets.empty()
            self.aliens.empty()

            self._create_fleet() # this creates a fleet
            self.settings.increase_speed() # this increasis the speed
            self.ship.center_ship() # this center the ship in the middle of the screen
            pygame.mouse.set_visible(False) # this is set to hide wehn you start the game

    def _check_keydown_events(self, event): # this checks all th clicks on the key board
        if event.key == pygame.K_RIGHT:
            self.ship.moving_right = True
        elif event.key == pygame.K_LEFT:
            self.ship.moving_left = True
        elif event.key == pygame.K_q:
            sys.exit()
        elif event.key == pygame.K_SPACE:
            self._fire_bullet() # this fires the bullet

    def _check_keyup_events(self, event): # this says once the key is stoped pressed the right or left stops mobving
        if event.key == pygame.K_RIGHT:
            self.ship.moving_right = False
        elif event.key == pygame.K_LEFT:
            self.ship.moving_left = False

    def _fire_bullet(self): # this code fires the bullets
        if len(self.bullets) < self.settings.bullets_allowed: # this says hjow many bullets are allowed on the screen
            new_bullet = Bullet(self) # this make the new bullet
            self.bullets.add(new_bullet) # this adds the new bullet

    def _update_screen(self):
        self.screen.fill(self.settings.bg_color) # this fills the screen with the background co,or that we choose
        for bullet in self.bullets.sprites(): # this make the bullets a sprite not a image
            bullet.draw_bullet() # this draws the bullets
        self.ship.blitme() # this blits the code
        self.aliens.draw(self.screen) # this draws the aliens

        self.sb.show_score() # this schows high scores

        if not self.game_active: # this says if the game is not active
            self.play_button.draw_button() # this draws the play button
        pygame.display.flip() # this flips the screen so we or the user can se


if __name__ == '__main__':
    ai = AlienInvasion() # this says if we ever used the alien invasion as ai
    ai.run_game() # this code runs the game
