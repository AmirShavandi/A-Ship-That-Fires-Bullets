count = int(input('Enter a number: '))

def test():
    global count
    count = count * 3
    print(f"{count} is the number times 3")

test()
print(f"The final value of count is {count}")