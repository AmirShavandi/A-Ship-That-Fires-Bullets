from tkinter import *
tk = Tk()
canvas = Canvas(width=300, height=100)
canvas.pack()
canvas.create_arc(10, 10, 200, 100, start=0, extent=180, style=ARC)
tk.mainloop()