import time
from tkinter import *
tk = Tk()
canvas = Canvas(tk, width = 900, height = 900)
canvas.pack()
canvas.create_text(150 , 150, text='hello its me hi', font = ('Times', 15))
for x in range(0, 60):
    canvas.move(1,5, 5)
    tk.update()
    time.sleep(0.5)


tk.mainloop()


