import pygame
import sys

# Initialize Pygame
pygame.init()

# Set up the display
window_size = (800, 600)  # You can change this to the size of your window
window = pygame.display.set_mode(window_size)
pygame.display.set_caption('Display Image with Pygame')

# Load an image
image_path = 'r2.jpg'  # Replace with the path to your image file
image = pygame.image.load(image_path)

# Main loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Clear the screen
    window.fill((255, 255, 255))  # Fill with white color

    # Draw the image at the center of the window
    image_rect = image.get_rect(center=(window_size[0]//2, window_size[1]//2))
    window.blit(image, image_rect)

    # Update the display
    pygame.display.flip()

# Quit Pygame
pygame.quit()
sys.exit()