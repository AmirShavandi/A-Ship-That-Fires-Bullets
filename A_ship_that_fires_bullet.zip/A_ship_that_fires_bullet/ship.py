import pygame # we import pygame
from pygame.sprite import Sprite # we import sprite

class Ship(Sprite): # we impoort ship
    """A class to manage the ship."""

    def __init__(self, ai_game): # we make a def
        """Initialize the ship and set its starting position."""
        super().__init__()  # Initialize the sprite
        self.screen = ai_game.screen  # this code says to import the ship on the screen
        self.settings = ai_game.settings # this gets the ships settings
        self.screen_rect = ai_game.screen.get_rect() # this rects the screen

        # Load the ship image and get its rect.
        self.image = pygame.image.load("ship.bmp")  # this loads the path to the pic
        self.rect = self.image.get_rect() # this gets the images rect

        # Start each new ship at the bottom center of the screen.
        self.rect.midbottom = self.screen_rect.midbottom # this says for it to spawn on the

        # Store a decimal value for the ship's horizontal position.
        self.x = float(self.rect.x)

        # Movement flag
        self.moving_right = False # this says so wehn the game strats ti doesent randomly go to the left or go to the right
        self.moving_left = False

    def update(self): #  this updates the screen
        """Update the ship's position based on the movement flag."""
        if self.moving_right and self.rect.right < self.screen_rect.right: # this gets the rect for the left and the right
            self.x += self.settings.ship_speed
        if self.moving_left and self.rect.left > 0:
            self.x -= self.settings.ship_speed

        # Update rect object from self.x.
        self.rect.x = self.x # this says  rect x = rect x

    def blitme(self): # this blits the screen so the image
        """Draw the ship at its current location."""
        self.screen.blit(self.image, self.rect) # this code loades the image

    def center_ship(self):
        """Center the ship on the screen."""
        self.rect.midbottom = self.screen_rect.midbottom # this positions the shi to center the bottom
        self.x = float(self.rect.x)
